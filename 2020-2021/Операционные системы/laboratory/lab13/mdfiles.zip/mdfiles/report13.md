---
# Front matter
lang: ru-RU
title: "Лабораторная работа 13"
subtitle: "Дисциплина: Операционные системы"
author: "Куликов Максим Игоревич"

# Formatting
toc-title: "Содержание"
toc: true # Table of contents
toc_depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4paper
documentclass: scrreprt
polyglossia-lang: russian
polyglossia-otherlangs: english
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase
indent: true
pdf-engine: lualatex
header-includes:
  - \linepenalty=10 # the penalty added to the badness of each line within a paragraph (no associated penalty node) Increasing the value makes tex try to have fewer lines in the paragraph.
  - \interlinepenalty=0 # value of the penalty (node) added after each line of a paragraph.
  - \hyphenpenalty=50 # the penalty for line breaking at an automatically inserted hyphen
  - \exhyphenpenalty=50 # the penalty for line breaking at an explicit hyphen
  - \binoppenalty=700 # the penalty for breaking a line at a binary operator
  - \relpenalty=500 # the penalty for breaking a line at a relation
  - \clubpenalty=150 # extra penalty for breaking after first line of a paragraph
  - \widowpenalty=150 # extra penalty for breaking before last line of a paragraph
  - \displaywidowpenalty=50 # extra penalty for breaking before last line before a display math
  - \brokenpenalty=100 # extra penalty for page breaking after a hyphenated line
  - \predisplaypenalty=10000 # penalty for breaking before a display
  - \postdisplaypenalty=0 # penalty for breaking after a display
  - \floatingpenalty = 20000 # penalty for splitting an insertion (can only be split footnote in standard LaTeX)
  - \raggedbottom # or \flushbottom
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Изучить основы программирования в оболочке ОС UNIX. Научиться писать более сложные командные файлы с использованием логических управляющих конструкций и циклов.

# Задание

1. Ознакомиться с теоретическим материалом.
2. Выполнить работу.


# Выполнение лабораторной работы

1. Создаю файл с расширением "sh", в котором пишу скрипт, который является упрощенным механизмом семафоров (рис. -@fig:001)

![Первый скрипт](image/1.png){ #fig:001 width=70% }

2. Тест скрипта. Работает исправно (рис. -@fig:002)

![Тест №1](image/2.png){ #fig:002 width=70% }

3. Создаю файл с расширением "sh", в котором пишу скрипт, который реализовывает команду man (рис. -@fig:003)

![Второй скрипт](image/3.png){ #fig:003 width=70% }

4. Запускаю скрипт. Он должен должен выдать справку об команде "ls" (рис. -@fig:004)

![Запуск скрипта](image/4.png){ #fig:004 width=70% }

5. Скрипт работает исправно (рис. -@fig:005)

![Тест №2](image/5.png){ #fig:005 width=70% }

6. Создаю файл с расширением "sh", в котором пишу скрипт, который принимает занчение с клавиатуры и выводит на экран строку из рандомных символов, длина которой равна числу, введённому с клавиатуры (рис. -@fig:006)

![Содержание 3 скрипта](image/6.png){ #fig:006 width=70% }

7. Тестирую скрипт №3. Работает верно (рис. -@fig:007)

![Тест №3](image/7.png){ #fig:007 width=70% }

# Выводы

Изучил основы программирования в оболочке ОС UNIX. Научился писать более сложные командные файлы с использованием логических управляющих конструкций и циклов.

# Контрольные вопросы

1. Найдите синтаксическую ошибку в следующей строке while [$1 != "exit"]
)$1 следует внести в кавычки(«»)
2. Как объединить (конкатенация) несколько строк в одну? 
С помощью знака >,| 
3. Найдите информацию об утилите seq. Какими иными способами можно реализовать ее функционал при программировании на bash? 
Эта утилита выводит последовательность целых чисел с заданным шагом. Также можно реализовать с помощью утилиты jot.
4. Какой результат даст вычисление выражения $((10/3))?
Результат: 3.
5. Укажите кратко основные отличия командной оболочки zsh от bash. 
    В zsh можно настроить отдельные сочетания клавиш так, как вам нравится. Использование истории команд в zsh ничем особенным не отличается от bash.
    Zsh очень удобен для повседневной работы и делает добрую половину рутины за вас. Но стоит обратить внимание на различия между этими двумя оболочками. Например, в zsh после for обязательно вставлять пробел, нумерация массивов в zsh начинается с 1, чего совершенно невозможно понять.
  Так, если вы используете shell для повседневной работы, исключающей написание скриптов, используйте zsh. Если вам часто приходится писать свои скрипты, только bash! Впрочем, можно комбинировать.
Как установить zsh в качестве оболочки по-умолчанию для отдельного пользователя:о
6. Проверьте, верен ли синтаксис данной конструкции for ((a=1; a <= LIMIT; a++)) 
Синтаксис верен.
7. Сравните язык bash с языками программирования, которые вы знайте. Какие преимущества у bash по сравнению с ними? Какие недостатки?
    1. Скорость работы программ на ассемблере может быть более 50% медленнее, чем программ на си/си++, скомпилированных с максимальной оптимизаций; 
    2. Скорость работы виртуальной ява-машины с байт-кодом часто превосходит скорость аппаратуры с кодами, получаемыми трансляторами с языков высокого уровня. Ява-машина уступает по скорости только ассемблеру и лучшим оптимизирующим трансляторам; 
    3. Скорость компиляции и исполнения программ на яваскрипт в популярных браузерах лишь в 2-3 раза уступает лучшим трансляторам и превосходит даже некоторые качественные компиляторы, безусловно намного (более чем в 10 раз) обгоняя большинство трансляторов других языков сценариев и подобных им по скорости исполнения программ; 
    4. Скорость кодов, генерируемых компилятором языка си фирмы Intel, оказалась заметно меньшей, чем компилятора GNU и иногда LLVM; 
    5. Скорость ассемблерных кодов x86-64 может меньше, чем аналогичных кодов x86, примерно на 10%; 
    6. Оптимизация кодов лучше работает на процессоре Intel; 
    7. Скорость исполнения на процессоре Intel была почти всегда выше, за исключением языков лисп, эрланг, аук (gawk, mawk) и бэш. Разница в скорости по бэш скорее всего вызвана разными настройками окружения на тестируемых системах, а не собственно транслятором или железом. Преимущество Intel особенно заметно на 32-разрядных кодах; 
    8. Стек большинства тестируемых языков, в частности, ява и яваскрипт, поддерживают только очень ограниченное число рекурсивных вызовов. Некоторые трансляторы (gcc, icc, ...) позволяют увеличить размер стека изменением переменных среды исполнения или параметром; 
    9. В рассматриваемых версиях gawk, php, perl, bash реализован динамический стек, позволяющий использовать всю память компьютера. Но perl и, особенно, bash используют стек настолько экстенсивно, что 8-16 ГБ не хватает для расчета ack(5,2,3)
