---
# Front matter
lang: ru-RU
title: "Лабораторная работа 10"
subtitle: "Дисциплина: Операционные системы"
author: "Куликов Максим Игоревич"

# Formatting
toc-title: "Содержание"
toc: true # Table of contents
toc_depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4paper
documentclass: scrreprt
polyglossia-lang: russian
polyglossia-otherlangs: english
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase
indent: true
pdf-engine: lualatex
header-includes:
  - \linepenalty=10 # the penalty added to the badness of each line within a paragraph (no associated penalty node) Increasing the value makes tex try to have fewer lines in the paragraph.
  - \interlinepenalty=0 # value of the penalty (node) added after each line of a paragraph.
  - \hyphenpenalty=50 # the penalty for line breaking at an automatically inserted hyphen
  - \exhyphenpenalty=50 # the penalty for line breaking at an explicit hyphen
  - \binoppenalty=700 # the penalty for breaking a line at a binary operator
  - \relpenalty=500 # the penalty for breaking a line at a relation
  - \clubpenalty=150 # extra penalty for breaking after first line of a paragraph
  - \widowpenalty=150 # extra penalty for breaking before last line of a paragraph
  - \displaywidowpenalty=50 # extra penalty for breaking before last line before a display math
  - \brokenpenalty=100 # extra penalty for page breaking after a hyphenated line
  - \predisplaypenalty=10000 # penalty for breaking before a display
  - \postdisplaypenalty=0 # penalty for breaking after a display
  - \floatingpenalty = 20000 # penalty for splitting an insertion (can only be split footnote in standard LaTeX)
  - \raggedbottom # or \flushbottom
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Познакомиться с операционной системой Linux. Получить практические навы-ки работы с редактором Emacs.

# Задание

1. Ознакомиться с теоретическим материалом.
2. Ознакомиться с редактором emacs.
3. Выполнить упражнения.
4. Ответить на контрольные вопросы.


# Выполнение лабораторной работы

1. Открыл emacs и создал файл lab10.sh. Ввёл текст в файл (рис. -@fig:001)

![Создание и выбор каталога](image/1.png){ #fig:001 width=70% }

2. Вырезал одной командой целую строку (рис. -@fig:002)

![Удаление строки](image/2.png){ #fig:002 width=70% }

3. Вставил эту строку в конец файла (рис. -@fig:003)

![Вставка строки](image/3.png){ #fig:003 width=70% }

4. Выделил область текста и скопировал (рис. -@fig:004)

![Выделение и копирование](image/4.png){ #fig:004 width=70% }

5. Вставил область в конец файла (рис. -@fig:005)

![Вставка текста](image/5.png){ #fig:005 width=70% }

6. Вновь выделил эту область и вырезал ее (рис. -@fig:006)

![Вырез текста](image/6.png){ #fig:006 width=70% }

7. Отменил последнее действие (рис. -@fig:007)

![Отмена действия](image/7.png){ #fig:007 width=70% }

8. Вывел список активных буферов на экран (рис. -@fig:008)

![Вывел список буферов](image/8.png){ #fig:08 width=70% }

9. Закрыл это окно (рис. -@fig:009)

![Закрытие окна](image/9.png){ #fig:09 width=70% }

10. Вновь переключился между буферами (рис. -@fig:010)

![Переключение буфера](image/10.png){ #fig:010 width=70% }

11. Разделил окно на 4 части (рис. -@fig:011)

![Разделение окна](image/11.png){ #fig:011 width=70% }

12. Открываю новые файлы и ввожу текст (рис. -@fig:012)

![Открытие файлов](image/12.png){ #fig:012 width=70% }

13. Поиск текста в файле (рис. -@fig:013)

![Поиск текста](image/13.png){ #fig:013 width=70% }

14. Использование режима поиска (рис. -@fig:014)

![Поиск](image/14.png){ #fig:014 width=70% }


# Выводы

Познакомился с операционной системой Linux. Получить практические навы-ки работы с редактором Emacs.

# Контрольные вопросы

1. Emacs представляет собой мощный экранный редактор текста, написанный на языке высокого уровня Elisp. 
 2. Для работы с emacs используется система меню и комбинаций клавиш. Используются сочетания c клавишами <ctrl> и <meta>. Сложности могут возникнуть так как на клавиатуре для IBM PC совместимых ПК клавиши <meta> нет, то вместо нее можно использовать <alt> или <esc>\verb . Для доступа к системе меню используйте клавишу F10.
3. В терминологии emacs’а буфер- это область где мы набираем текст, а окно область, которая объединяет открытые буферы. 
4. Можно открыть больше 10 буферов в одном окне.
5.  Создаются по умолчанию при запуске emacs:
        % *GNU Emacs* 844 Fundamental 
       *scratch* 191 Lisp Interaction 
        %* *Messages* 5257 Messages 
        % *Quail Completions* 0 Fundamental
6.  Клавиши: Ctrl,C,Shift,\,] и <esc>,Ctrl,C Ctrl,Shift,\,]
7. Разделите фрейм на два окна по вертикали C-x 3, окно на две части по горизонтали C-x 2
8. В файле Emacs хранятся настройки редактора emacs.
9.  Kнопка backspace( стереть букву ) = функции C-k и ее можно переназначить.
10. Emacs оказался намного удобнее. В нём больше функций, в нём интересно редактировать информацию.
